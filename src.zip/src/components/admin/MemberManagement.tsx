import { useState } from "react";
import { recentMembers } from "../../data/dummyData";

type Member = {
  id: string;
  name: string;
  email: string;
  date: string;
};

function MemberManagement() {
  const [members, setMembers] = useState<Member[]>(recentMembers);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  const handleSaveMember = () => {
    if (!selectedMember) return;

    setMembers((prev) =>
      prev.map((member) =>
        member.id === selectedMember.id ? selectedMember : member,
      ),
    );

    setSelectedMember(null);
  };

  return (
    <>
      <section className="content-box member-page-box">
        <div className="member-header">
          <h3>회원 관리</h3>
          <button className="add-member-button">+ 회원 추가</button>
        </div>

        <div className="member-search-box">
          <span>🔍</span>
          <input placeholder="아이디, 이름, 이메일 검색" />
        </div>

        <table className="admin-table member-table">
          <thead>
            <tr>
              <th>아이디</th>
              <th>이름</th>
              <th>이메일</th>
              <th>가입일</th>
              <th>상태</th>
              <th>관리</th>
            </tr>
          </thead>

          <tbody>
            {members.map((member, index) => (
              <tr key={member.id}>
                <td>{member.id}</td>
                <td>{member.name}</td>
                <td>{member.email}</td>
                <td>{member.date}</td>
                <td>
                  <span
                    className={`member-status ${
                      index === members.length - 1 ? "inactive" : "active"
                    }`}
                  >
                    {index === members.length - 1 ? "비활성" : "활성"}
                  </span>
                </td>
                <td>
                  <div className="member-action">
                    <button
                      className="member-edit-button"
                      onClick={() => setSelectedMember(member)}
                    >
                      수정
                    </button>
                    <button className="member-delete-button">삭제</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="pagination">
          <button className="page-button active">1</button>
          <button className="page-button">2</button>
          <button className="page-button">3</button>
          <button className="page-button">4</button>
          <button className="page-button">5</button>
          <button className="page-button">〉</button>
        </div>
      </section>

      {selectedMember && (
        <div className="modal-backdrop">
          <div className="edit-modal">
            <div className="modal-header">
              <h3>회원정보 수정</h3>
              <button onClick={() => setSelectedMember(null)}>×</button>
            </div>

            <div className="modal-body">
              <label>아이디</label>
              <input value={selectedMember.id} disabled />

              <label>이름</label>
              <input
                value={selectedMember.name}
                onChange={(e) =>
                  setSelectedMember({
                    ...selectedMember,
                    name: e.target.value,
                  })
                }
              />

              <label>이메일</label>
              <input
                value={selectedMember.email}
                onChange={(e) =>
                  setSelectedMember({
                    ...selectedMember,
                    email: e.target.value,
                  })
                }
              />

              <label>가입일</label>
              <input
                value={selectedMember.date}
                onChange={(e) =>
                  setSelectedMember({
                    ...selectedMember,
                    date: e.target.value,
                  })
                }
              />
            </div>

            <div className="modal-footer">
              <button
                className="cancel-button"
                onClick={() => setSelectedMember(null)}
              >
                취소
              </button>
              <button className="save-button" onClick={handleSaveMember}>
                저장
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default MemberManagement;
