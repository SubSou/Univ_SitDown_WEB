import { stats, recentMembers } from "../../data/dummyData";

function DashboardMain() {
  return (
    <section className="dashboard-content">
      <div className="stats-grid">
        {stats.map((item) => (
          <div className="stat-card" key={item.title}>
            <p>{item.title}</p>
            <h2>{item.value}</h2>
          </div>
        ))}
      </div>

      <section className="content-box member-page-box">
        <div className="box-header">
          <h3>최근 가입 회원</h3>
          <button>더보기 〉</button>
        </div>

        <table className="admin-table member-table">
          <thead>
            <tr>
              <th>아이디</th>
              <th>이름</th>
              <th>이메일</th>
              <th>가입일</th>
            </tr>
          </thead>

          <tbody>
            {recentMembers.map((member) => (
              <tr key={member.id}>
                <td>{member.id}</td>
                <td>{member.name}</td>
                <td>{member.email}</td>
                <td>{member.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </section>
  );
}

export default DashboardMain;
