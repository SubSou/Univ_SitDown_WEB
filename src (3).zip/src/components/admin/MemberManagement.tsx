import { useEffect, useState } from "react";
import { Search, X } from "lucide-react";
import {
  getAdminUsers,
  getAdminUserDetail,
  updateAdminUser,
  type AdminUser,
} from "../../api/adminApi";

export default function MemberManagement() {
  const [memberList, setMemberList] = useState<AdminUser[]>([]);
  const [keyword, setKeyword] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [editName, setEditName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editAffiliation, setEditAffiliation] = useState("");

  const loadMembers = async () => {
    try {
      const response = await getAdminUsers(page, 20);
      setMemberList(response.content);
      setTotalPages(response.totalPages);
    } catch (e) {
      console.error(e);
      alert("회원 목록 조회 실패");
    }
  };

  useEffect(() => {
    let ignore = false;

    const fetchMembers = async () => {
      await Promise.resolve();

      try {
        setLoading(true);

        const response = await getAdminUsers(page, 20);

        if (!ignore) {
          setMemberList(response.content);
          setTotalPages(response.totalPages);
        }
      } catch (e) {
        console.error(e);

        if (!ignore) {
          alert("회원 목록 조회 실패");
        }
      } finally {
        if (!ignore) {
          setLoading(false);
        }
      }
    };

    fetchMembers();

    return () => {
      ignore = true;
    };
  }, [page]);

  const filteredMembers = memberList.filter((member) => {
    const searchText = `${member.id} ${member.name} ${member.email}`;
    return searchText.toLowerCase().includes(keyword.toLowerCase());
  });

  const openEditModal = async (userId: string) => {
    try {
      const userDetail = await getAdminUserDetail(userId);

      setSelectedUser(userDetail);
      setEditName(userDetail.name ?? "");
      setEditPhone(userDetail.phone ?? "");
      setEditAffiliation(userDetail.affiliation ?? "");

      setIsEditModalOpen(true);
    } catch (e) {
      console.error(e);
      alert("회원 상세 조회 실패");
    }
  };

  const closeEditModal = () => {
    setIsEditModalOpen(false);
    setSelectedUser(null);
    setEditName("");
    setEditPhone("");
    setEditAffiliation("");
  };

  const handleUpdateUser = async () => {
    if (!selectedUser) return;

    try {
      await updateAdminUser(selectedUser.id, {
        name: editName,
        phone: editPhone,
        affiliation: editAffiliation,
      });

      alert("회원 정보가 수정되었습니다.");
      closeEditModal();
      await loadMembers();
    } catch (e) {
      console.error(e);
      alert("회원 정보 수정 실패");
    }
  };

  if (loading) {
    return <div className="member-page">회원 목록 불러오는 중...</div>;
  }

  return (
    <section className="member-page">
      <div className="member-card">
        <div className="member-toolbar">
          <div className="member-search-box">
            <Search size={18} color="#8b95a1" />
            <input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="아이디, 이름, 이메일 검색"
            />
          </div>

          <button className="member-add-button">+ 회원 추가</button>
        </div>

        <div className="member-table-wrap">
          <table className="member-table">
            <thead>
              <tr>
                <th>아이디</th>
                <th>이름</th>
                <th>이메일</th>
                <th>가입일</th>
                <th>관리</th>
              </tr>
            </thead>

            <tbody>
              {filteredMembers.map((member) => (
                <tr key={member.id}>
                  <td>{member.id}</td>
                  <td>{member.name}</td>
                  <td>{member.email}</td>
                  <td>{member.createdAt}</td>
                  <td>
                    <div className="member-actions">
                      <button
                        className="member-edit-button"
                        onClick={() => openEditModal(member.id)}
                      >
                        수정
                      </button>

                      <button className="member-delete-button">삭제</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="member-pagination">
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              className={page === index ? "active" : ""}
              onClick={() => setPage(index)}
            >
              {index + 1}
            </button>
          ))}

          {page + 1 < totalPages && (
            <button onClick={() => setPage(page + 1)}>〉</button>
          )}
        </div>
      </div>

      {isEditModalOpen && selectedUser && (
        <div className="member-modal-overlay">
          <div className="member-modal">
            <div className="member-modal-header">
              <h3>회원 정보 수정</h3>

              <button
                type="button"
                className="member-modal-close-button"
                onClick={closeEditModal}
              >
                <X size={20} strokeWidth={2.2} />
              </button>
            </div>

            <div className="member-modal-body">
              <div className="member-form-group">
                <label>아이디</label>
                <input value={selectedUser.id} disabled />
              </div>

              <div className="member-form-group">
                <label>이메일</label>
                <input value={selectedUser.email} disabled />
              </div>

              <div className="member-form-group">
                <label>이름</label>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="이름을 입력하세요"
                />
              </div>

              <div className="member-form-group">
                <label>전화번호</label>
                <input
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  placeholder="전화번호를 입력하세요"
                />
              </div>

              <div className="member-form-group">
                <label>소속</label>
                <input
                  value={editAffiliation}
                  onChange={(e) => setEditAffiliation(e.target.value)}
                  placeholder="소속을 입력하세요"
                />
              </div>
            </div>

            <div className="member-modal-footer">
              <button className="member-modal-cancel" onClick={closeEditModal}>
                취소
              </button>

              <button className="member-modal-save" onClick={handleUpdateUser}>
                수정하기
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
