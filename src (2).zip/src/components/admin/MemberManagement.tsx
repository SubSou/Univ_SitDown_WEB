import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { getAdminUsers, type AdminUser } from "../../api/adminApi";

export default function MemberManagement() {
  const [memberList, setMemberList] = useState<AdminUser[]>([]);
  const [keyword, setKeyword] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let ignore = false;

    const fetchMembers = async () => {
      try {
        const response = await getAdminUsers(page, 20);

        if (!ignore) {
          setMemberList(response.content);
          setTotalPages(response.totalPages);
        }
      } catch (e) {
        console.error(e);

        if (!ignore) {
          alert("회원 목록 조회 실패");
        }
      } finally {
        if (!ignore) {
          setLoading(false);
        }
      }
    };

    fetchMembers();

    return () => {
      ignore = true;
    };
  }, [page]);

  const filteredMembers = memberList.filter((member) => {
    const searchText = `${member.id} ${member.name} ${member.email}`;
    return searchText.toLowerCase().includes(keyword.toLowerCase());
  });

  if (loading) {
    return <div className="member-page">회원 목록 불러오는 중...</div>;
  }

  return (
    <section className="member-page">
      <div className="member-card">
        <div className="member-toolbar">
          <div className="member-search-box">
            <Search size={18} color="#8b95a1" />
            <input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="아이디, 이름, 이메일 검색"
            />
          </div>

          <button className="member-add-button">+ 회원 추가</button>
        </div>
        <div className="member-table-wrap">
          <table className="member-table">
            <thead>
              <tr>
                <th>아이디</th>
                <th>이름</th>
                <th>이메일</th>
                <th>가입일</th>
                <th>관리</th>
              </tr>
            </thead>

            <tbody>
              {filteredMembers.map((member) => (
                <tr key={member.id}>
                  <td>{member.id}</td>
                  <td>{member.name}</td>
                  <td>{member.email}</td>
                  <td>{member.createdAt}</td>
                  <td>
                    <div className="member-actions">
                      <button className="member-edit-button">수정</button>

                      <button className="member-delete-button">삭제</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="member-pagination">
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              className={page === index ? "active" : ""}
              onClick={() => setPage(index)}
            >
              {index + 1}
            </button>
          ))}

          {page + 1 < totalPages && (
            <button onClick={() => setPage(page + 1)}>〉</button>
          )}
        </div>
      </div>
    </section>
  );
}
