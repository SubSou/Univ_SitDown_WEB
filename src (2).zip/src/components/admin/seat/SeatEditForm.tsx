import { Fragment } from "react";
import type { EditSeat } from "./types";

const EDIT_COLUMNS = [8, 9, 10, 11, 12, 13, 14];
const EDIT_ROWS = ["A", "B", "C", "D", "E"];

type SeatEditFormProps = {
  editSeat: EditSeat;
  isSubmitting: boolean;
  onChange: (seat: EditSeat) => void;
  onCancel: () => void;
  onSave: () => void;
};

function SeatEditForm({
  editSeat,
  isSubmitting,
  onChange,
  onCancel,
  onSave,
}: SeatEditFormProps) {
  const updateSeat = <K extends keyof EditSeat>(key: K, value: EditSeat[K]) => {
    onChange({ ...editSeat, [key]: value });
  };

  const getSeatClassName = (row: string, col: number) => {
    const code = `${row}-${col}`;
    const isSelected = editSeat.code === code;

    if (isSelected) return "seat-box selected";
    if (row === "D" && (col === 10 || col === 11)) return "seat-box reserved";
    if (row === "E" && col >= 11) return "seat-box disabled";
    return "seat-box available";
  };

  return (
    <section className="seat-edit-page">
      <div className="seat-edit-card">
        <div className="seat-edit-left">
          <div className="form-row">
            <label>좌석 코드</label>
            <input value={editSeat.code} readOnly />
          </div>

          <div className="form-row">
            <label>공간</label>
            <input value={editSeat.space} readOnly />
          </div>

          <div className="form-row">
            <label>구역</label>
            <select value={editSeat.area} onChange={(e) => updateSeat("area", e.target.value)}>
              <option>A 구역</option>
              <option>B 구역</option>
              <option>C 구역</option>
            </select>
          </div>

          <div className="form-row">
            <label>행</label>
            <select value={editSeat.row} onChange={(e) => updateSeat("row", e.target.value)}>
              {EDIT_ROWS.map((row) => (
                <option key={row}>{row}</option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <label>열</label>
            <select value={editSeat.col} onChange={(e) => updateSeat("col", e.target.value)}>
              {EDIT_COLUMNS.map((col) => (
                <option key={col}>{col}</option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <label>좌석 유형</label>
            <select value={editSeat.type} onChange={(e) => updateSeat("type", e.target.value)}>
              <option>일반 좌석</option>
              <option>PC 좌석</option>
              <option>스터디룸</option>
            </select>
          </div>

          <div className="form-row">
            <label>특징</label>
            <input
              value={editSeat.feature}
              onChange={(e) => updateSeat("feature", e.target.value)}
            />
          </div>

          <div className="form-row">
            <label>상태</label>
            <select value={editSeat.status} onChange={(e) => updateSeat("status", e.target.value)}>
              <option>사용 가능</option>
              <option>사용 중</option>
              <option>예약 중</option>
              <option>사용 불가</option>
            </select>
          </div>
        </div>

        <div className="seat-edit-right">
          <h3>좌석 선택</h3>

          <div className="edit-seat-map">
            <div />

            {EDIT_COLUMNS.map((col) => (
              <strong key={col}>{col}</strong>
            ))}

            {EDIT_ROWS.map((row) => (
              <Fragment key={row}>
                <strong>{row}</strong>

                {EDIT_COLUMNS.map((col) => {
                  const code = `${row}-${col}`;
                  const className = getSeatClassName(row, col);
                  const isSelected = editSeat.code === code;

                  return (
                    <button
                      key={code}
                      type="button"
                      className={className}
                      disabled={className.includes("disabled")}
                      onClick={() =>
                        onChange({
                          ...editSeat,
                          code,
                          row,
                          col: String(col),
                        })
                      }
                    >
                      {isSelected ? code : ""}
                    </button>
                  );
                })}
              </Fragment>
            ))}
          </div>

          <div className="seat-map-legend">
            <span><i className="available" /> 사용 가능</span>
            <span><i className="selected" /> 사용 중</span>
            <span><i className="booking" /> 예약 중</span>
            <span><i className="disabled" /> 사용 불가</span>
          </div>
        </div>

        <div className="seat-edit-footer">
          <button className="cancel-button" onClick={onCancel}>취소</button>
          <button className="save-button" onClick={onSave} disabled={isSubmitting}>
            {isSubmitting ? "저장 중..." : "저장"}
          </button>
        </div>
      </div>
    </section>
  );
}

export default SeatEditForm;
