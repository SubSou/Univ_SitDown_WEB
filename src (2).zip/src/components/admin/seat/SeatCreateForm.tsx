import type { CreateSeatForm } from "./types";

type SeatCreateFormProps = {
  form: CreateSeatForm;
  onChange: (form: CreateSeatForm) => void;
  onCancel: () => void;
  onNext: () => void;
};

function SeatCreateForm({ form, onChange, onCancel, onNext }: SeatCreateFormProps) {
  const updateForm = <K extends keyof CreateSeatForm>(
    key: K,
    value: CreateSeatForm[K],
  ) => {
    onChange({ ...form, [key]: value });
  };

  return (
    <section className="seat-create-page">
      <div className="seat-step-card">
        <h3>좌석 정보 입력</h3>

        <label>공간 선택</label>
        <select value={form.space} onChange={(e) => updateForm("space", e.target.value)}>
          <option>제1열람실 3층</option>
          <option>제2열람실 2층</option>
          <option>스터디룸 A</option>
        </select>

        <label>구역</label>
        <select value={form.area} onChange={(e) => updateForm("area", e.target.value)}>
          <option>A 구역</option>
          <option>B 구역</option>
          <option>C 구역</option>
        </select>

        <label>좌석 유형</label>
        <select value={form.type} onChange={(e) => updateForm("type", e.target.value)}>
          <option>일반 좌석</option>
          <option>PC 좌석</option>
          <option>스터디룸</option>
        </select>

        <label>행 수</label>
        <div className="seat-count-box">
          <button type="button" onClick={() => updateForm("rows", Math.max(1, form.rows - 1))}>-</button>
          <span>{form.rows}</span>
          <button type="button" onClick={() => updateForm("rows", Math.min(20, form.rows + 1))}>+</button>
        </div>

        <label>열 수</label>
        <div className="seat-count-box">
          <button type="button" onClick={() => updateForm("cols", Math.max(1, form.cols - 1))}>-</button>
          <span>{form.cols}</span>
          <button type="button" onClick={() => updateForm("cols", Math.min(20, form.cols + 1))}>+</button>
        </div>

        <label>특징</label>
        <input
          placeholder="예) 콘센트, 창가"
          value={form.feature}
          onChange={(e) => updateForm("feature", e.target.value)}
        />

        <div className="seat-step-footer">
          <button className="cancel-button" onClick={onCancel}>취소</button>
          <button className="save-button" onClick={onNext}>다음</button>
        </div>
      </div>
    </section>
  );
}

export default SeatCreateForm;
