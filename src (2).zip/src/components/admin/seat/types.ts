export type SeatStep = "list" | "form" | "preview" | "complete" | "edit";

export type SeatItem = {
  code: string;
  area: string;
  row: string;
  col: string | number;
  type: string;
  feature: string;
  status: string;
};

export type EditSeat = {
  id: string;
  code: string;
  space: string;
  area: string;
  row: string;
  col: string;
  type: string;
  feature: string;
  status: string;
};

export type CreateSeatForm = {
  space: string;
  area: string;
  type: string;
  rows: number;
  cols: number;
  feature: string;
};
