import { useState } from "react";
import { noticeList } from "../../data/dummyData";

type Notice = {
  title: string;
  type: string;
  date: string;
};

function NoticeManagement() {
  const [notices, setNotices] = useState<Notice[]>(noticeList);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [newNotice, setNewNotice] = useState<Notice>({
    title: "",
    type: "공지",
    date: "",
  });

  const handleAddNotice = () => {
    if (!newNotice.title || !newNotice.date) {
      alert("제목과 등록일을 입력해주세요.");
      return;
    }

    setNotices((prev) => [newNotice, ...prev]);
    setNewNotice({ title: "", type: "공지", date: "" });
    setIsNoticeModalOpen(false);
  };

  return (
    <>
      <section className="content-box notice-page-box">
        <div className="notice-header">
          <h3>공지사항</h3>
          <button
            className="add-notice-button"
            onClick={() => setIsNoticeModalOpen(true)}
          >
            + 공지사항 추가
          </button>
        </div>

        <div className="notice-search-box">
          <span>🔍</span>
          <input placeholder="제목, 분류 검색" />
        </div>

        <table className="admin-table notice-table">
          <thead>
            <tr>
              <th>제목</th>
              <th>분류</th>
              <th>등록일</th>
              <th>관리</th>
            </tr>
          </thead>

          <tbody>
            {notices.map((notice, index) => (
              <tr key={`${notice.title}-${index}`}>
                <td>{notice.title}</td>
                <td>
                  <span className="notice-type-badge">{notice.type}</span>
                </td>
                <td>{notice.date}</td>
                <td>
                  <div className="notice-action">
                    <button className="notice-edit-button">수정</button>
                    <button className="notice-delete-button">삭제</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="pagination">
          <button className="page-button active">1</button>
          <button className="page-button">2</button>
          <button className="page-button">3</button>
          <button className="page-button">4</button>
          <button className="page-button">5</button>
          <button className="page-button">〉</button>
        </div>
      </section>

      {isNoticeModalOpen && (
        <div className="modal-backdrop">
          <div className="edit-modal">
            <div className="modal-header">
              <h3>공지사항 등록</h3>
              <button onClick={() => setIsNoticeModalOpen(false)}>×</button>
            </div>

            <div className="modal-body">
              <label>제목</label>
              <input
                value={newNotice.title}
                placeholder="공지사항 제목을 입력하세요"
                onChange={(e) =>
                  setNewNotice({ ...newNotice, title: e.target.value })
                }
              />

              <label>분류</label>
              <select
                className="modal-select"
                value={newNotice.type}
                onChange={(e) =>
                  setNewNotice({ ...newNotice, type: e.target.value })
                }
              >
                <option value="공지">공지</option>
                <option value="안내">안내</option>
                <option value="점검">점검</option>
                <option value="이벤트">이벤트</option>
              </select>

              <label>등록일</label>
              <input
                value={newNotice.date}
                placeholder="2024.05.22"
                onChange={(e) =>
                  setNewNotice({ ...newNotice, date: e.target.value })
                }
              />
            </div>

            <div className="modal-footer">
              <button
                className="cancel-button"
                onClick={() => setIsNoticeModalOpen(false)}
              >
                취소
              </button>
              <button className="save-button" onClick={handleAddNotice}>
                등록
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default NoticeManagement;
