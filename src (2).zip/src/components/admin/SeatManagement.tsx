import { useState } from "react";
import { createAdminSeatGrid, updateAdminSeatStatus } from "../../api/adminApi";
import { seatList } from "../../data/dummyData";
import SeatComplete from "./seat/SeatComplete";
import SeatCreateForm from "./seat/SeatCreateForm";
import SeatEditForm from "./seat/SeatEditForm";
import SeatList from "./seat/SeatList";
import SeatPreview from "./seat/SeatPreview";
import type { CreateSeatForm, EditSeat, SeatItem, SeatStep } from "./seat/types";

const DEFAULT_SPACE_ID = "space-001";

const DEFAULT_CREATE_FORM: CreateSeatForm = {
  space: "제1열람실 3층",
  area: "A 구역",
  type: "일반 좌석",
  rows: 5,
  cols: 10,
  feature: "",
};

const DEFAULT_EDIT_SEAT: EditSeat = {
  id: "A-12",
  code: "A-12",
  space: "제1열람실 3층",
  area: "A 구역",
  row: "A",
  col: "12",
  type: "일반 좌석",
  feature: "콘센트, 창가",
  status: "사용 가능",
};

function SeatManagement() {
  const [step, setStep] = useState<SeatStep>("list");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createForm, setCreateForm] = useState<CreateSeatForm>(DEFAULT_CREATE_FORM);
  const [editSeat, setEditSeat] = useState<EditSeat>(DEFAULT_EDIT_SEAT);

  const totalSeats = createForm.rows * createForm.cols;

  const resetCreateForm = () => {
    setCreateForm(DEFAULT_CREATE_FORM);
  };

  const handleAddClick = () => {
    resetCreateForm();
    setStep("form");
  };

  const handleEditClick = (seat: SeatItem) => {
    setEditSeat({
      // 실제 백엔드 연동 시에는 seat.code가 아니라 seat.id를 사용해야 합니다.
      id: seat.code,
      code: seat.code,
      space: seat.area,
      area: seat.area.includes("제1열람실") ? "A 구역" : "B 구역",
      row: seat.row,
      col: String(seat.col),
      type: seat.type,
      feature: seat.feature,
      status: seat.status,
    });

    setStep("edit");
  };

  const handleCreateSeats = async () => {
    try {
      setIsSubmitting(true);

      await createAdminSeatGrid(DEFAULT_SPACE_ID, {
        rows: createForm.rows,
        columns: createForm.cols,
        labelPrefix: createForm.area.slice(0, 1),
        overwrite: false,
      });

      setStep("complete");
    } catch (error) {
      alert(error instanceof Error ? error.message : "좌석 생성에 실패했습니다.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateSeat = async () => {
    try {
      setIsSubmitting(true);

      await updateAdminSeatStatus(editSeat.id, {
        isEnabled: editSeat.status !== "사용 불가",
      });

      alert("좌석 정보가 저장되었습니다.");
      setStep("list");
    } catch (error) {
      alert(error instanceof Error ? error.message : "좌석 수정에 실패했습니다.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (step === "form") {
    return (
      <SeatCreateForm
        form={createForm}
        onChange={setCreateForm}
        onCancel={() => setStep("list")}
        onNext={() => setStep("preview")}
      />
    );
  }

  if (step === "preview") {
    return (
      <SeatPreview
        rows={createForm.rows}
        cols={createForm.cols}
        isSubmitting={isSubmitting}
        onPrev={() => setStep("form")}
        onCreate={handleCreateSeats}
      />
    );
  }

  if (step === "complete") {
    return (
      <SeatComplete
        totalSeats={totalSeats}
        onConfirm={() => {
          resetCreateForm();
          setStep("list");
        }}
      />
    );
  }

  if (step === "edit") {
    return (
      <SeatEditForm
        editSeat={editSeat}
        isSubmitting={isSubmitting}
        onChange={setEditSeat}
        onCancel={() => setStep("list")}
        onSave={handleUpdateSeat}
      />
    );
  }

  return <SeatList seats={seatList} onAdd={handleAddClick} onEdit={handleEditClick} />;
}

export default SeatManagement;
